package ui;

import model.exception.LogException;

public class Main {
    public static void main(String[] args) throws LogException {
        new GUI();
    }
}
